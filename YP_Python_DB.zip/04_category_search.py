import pymysql
con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')

curs=con.cursor()
cat=input("Enter your category : ")
curs.execute("select * from books where Category='%s'" %cat)
data=curs.fetchall()
print(data)
con.close()

