import pymysql
con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')
curs=con.cursor()

try:
    auth=input("Enter the author name : ")
    pub=int(input("Enter the publication year :"))

    curs.execute("select * from books where Author='%s' and Publication=%d"%(auth,pub))
    data=curs.fetchall()
    print(data)

except Exception as e:
    print("Error:",e)

con.close()