import pymysql

code=int(input('Enter the bookcode : '))
con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')

curs=con.cursor()

try:
    curs.execute("select * from books where Bookcode='%d'" %code)
    res=curs.fetchone()

    print(res)

except Exception as e:
    print("Sorry book does not exist")
    print('Error:',e)

con.close()