import pymysql
con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')
curs=con.cursor()

try:
    code=int(input("Enter the bookcode :"))
    curs.execute("select * from books where bookcode=%d"%code)
    data=curs.fetchone()
    print(data)
    delete=input("Do you want to delete this book? : ")
    if delete.lower()=="yes":
        curs.execute("delete from books where Bookcode=%d"%code)
        con.commit()
        print("Book Deleted Successfully...")

    else:
        print('Book Does Not Exist')
except Exception as e:
    print('Error : ',e)

con.close()

