import pymysql
con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')

curs=con.cursor()

curs.execute("select Bookname from books ")
data=curs.fetchall()

print("List of the books are:",data)
con.close()
