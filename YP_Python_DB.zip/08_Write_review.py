import pymysql

con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')
curs=con.cursor()

try:
    code=int(input("Enter bookcode : "))
    curs.execute("select * from books where Bookcode=%d"%code)
    data=curs.fetchone()
    print(data)
    if data:
        review=input("Enter your review :")
        curs.execute("update books set review='%s' where Bookcode=%d"%(review,code))
        con.commit()
        print("Review saved...")
    else:
        print(" Book  does not exist ")
except Exception as e:
    print('Error :',e)

con.close()

    
