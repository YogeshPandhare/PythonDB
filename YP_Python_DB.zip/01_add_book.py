import pymysql

con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')
curs=con.cursor()


try:

    Bookcode=int(input("enter bookcode :"))
    Bookname=input("enter bookname :")
    Category=input("enter the category : ")
    Author=input("enter Author Name :")
    Publication=int(input("Enter the publication year :"))
    Edition=int(input("Enter edition number :"))
    Price=float(input("Enter the price of the book : "))
    review=input("Enter review :")

    curs.execute("INSERT INTO books Values(%d,'%s','%s','%s',%d,%d,'%.2f','%s')"%(Bookcode,Bookname,Category,Author,Publication,Edition,Price,review))
    con.commit()
    print("Book Inserted...")
except Exception as e:
    print("Error:",e)

con.close()

