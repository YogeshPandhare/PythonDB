import pymysql

con=pymysql.connect(host='bzgegflsmtpnxlmvelte-mysql.services.clever-cloud.com',user='ueostkb7u02gh9qi',password='Mfo0IOO0EH5v8ibpYR2H',database='bzgegflsmtpnxlmvelte')
curs=con.cursor()

try:
    code=int(input("Enter the bookcode to update the book price: "))
    curs.execute("select * from books where bookcode=%d"%code)
    data=curs.fetchone()
    if data:
        newp=int(input("Enter the updated price :"))
        curs.execute("update books set price=%d"%newp)
        con.commit()
        print("Book price updated successfully...")
    else:
        print("Sorry book does not exist")
except Exception as e:
    print("Error :",e)

con.close()